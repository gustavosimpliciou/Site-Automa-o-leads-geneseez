# Geneseez - Casa Criativa

## Overview
Geneseez é uma casa criativa dedicada à criação em diversas formas: música, arte, design, vídeos e fotografia. O nome "Geneseez" vem de "gênese" — o início de toda criação.

## Projeto em Destaque
- **Álbum:** ÊXTASE 999
- **Artistas:** DIIVINU & LOPZ
- **Faixas:** 9 músicas

## Project Structure
- `/src` - React source code
  - `/components` - React components (Header, Hero, About, Benefits, Projects, Contact, Footer, WhatsAppButton, ParticleAnimation)
  - `App.tsx` - Main application component with view routing
  - `main.tsx` - Entry point
  - `index.css` - Tailwind CSS styles
- `/public` - Static assets (logos, images)
- `vite.config.ts` - Vite configuration (port 5000, all hosts allowed)
- `tailwind.config.js` - Tailwind configuration
- `package.json` - Dependencies and scripts

## Tech Stack
- React 18
- TypeScript
- Vite 5
- Tailwind CSS
- Lucide React (icons)

## Development
Run `npm run dev` to start the development server on port 5000.

## Build
Run `npm run build` to create a production build in the `dist` folder.

## Serviços Oferecidos
- Música / Produção Musical
- Arte & Design
- Vídeo / Audiovisual
- Fotografia
