import { useEffect, useRef } from 'react';
import { Palette, Music, Video, Camera } from 'lucide-react';

const About: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            if (entry.target === textRef.current) {
              entry.target.classList.add('opacity-100', 'translate-x-0');
              entry.target.classList.remove('opacity-0', 'translate-x-[-50px]');
            } else if (entry.target === imageRef.current) {
              entry.target.classList.add('opacity-100', 'translate-x-0');
              entry.target.classList.remove('opacity-0', 'translate-x-[50px]');
            }
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );

    if (textRef.current) observer.observe(textRef.current);
    if (imageRef.current) observer.observe(imageRef.current);

    return () => {
      if (textRef.current) observer.unobserve(textRef.current);
      if (imageRef.current) observer.unobserve(imageRef.current);
    };
  }, []);

  const services = [
    { icon: <Music size={24} />, label: 'Música' },
    { icon: <Palette size={24} />, label: 'Arte & Design' },
    { icon: <Video size={24} />, label: 'Vídeos' },
    { icon: <Camera size={24} />, label: 'Fotografia' },
  ];

  return (
    <section id="about" className="py-24 bg-white">
      <div className="container mx-auto px-4" ref={sectionRef}>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div 
            className="transition-all duration-1000 opacity-0 translate-x-[-50px]" 
            ref={textRef}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-black">Quem Somos</h2>
            <p className="text-gray-700 mb-6">
              A Geneseez nasceu de um desejo simples: criar. Nosso nome vem de "gênese" — o início, a origem de tudo. 
              Acreditamos que cada grande obra começa com uma ideia, e nossa missão é transformar essas ideias em realidade.
            </p>
            <p className="text-gray-700 mb-6">
              Somos uma equipe de criativos apaixonados por música, arte visual, design gráfico, produção audiovisual e fotografia. 
              Não trabalhamos apenas com projetos — vivemos cada um deles. Entendemos que por trás de cada criação existe uma história, 
              uma emoção, um propósito que merece ser contado com autenticidade.
            </p>
            <p className="text-gray-700">
              Aqui, não existe fórmula pronta. Cada projeto é único, e tratamos cada cliente como parceiro. 
              Nosso compromisso é entregar trabalhos que não apenas impressionam visualmente, mas que conectam, 
              emocionam e deixam uma marca.
            </p>
          </div>
          <div 
            className="transition-all duration-1000 opacity-0 translate-x-[50px]" 
            ref={imageRef}
          >
            <div className="bg-gray-100 rounded-lg p-8 h-full">
              <div className="text-center mb-8">
                <div className="w-32 h-32 mx-auto bg-black rounded-full flex items-center justify-center mb-6">
                  <svg viewBox="0 0 24 24" className="w-16 h-16 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Criatividade Sem Limites</h3>
                <p className="text-gray-600 mb-6">
                  Da concepção à execução, transformamos visões em experiências memoráveis.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {services.map((service, index) => (
                  <div key={index} className="flex items-center gap-3 bg-white p-4 rounded-lg">
                    <div className="text-black">{service.icon}</div>
                    <span className="font-medium text-gray-800">{service.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
