import { useEffect, useRef } from 'react';
import { Heart, Sparkles, Users, Star } from 'lucide-react';

interface BenefitProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  delay: number;
}

const BenefitCard: React.FC<BenefitProps> = ({ title, description, icon, delay }) => {
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              entry.target.classList.add('opacity-100', 'translate-y-0');
              entry.target.classList.remove('opacity-0', 'translate-y-10');
            }, delay);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );

    if (cardRef.current) observer.observe(cardRef.current);

    return () => {
      if (cardRef.current) observer.unobserve(cardRef.current);
    };
  }, [delay]);

  return (
    <div 
      className="bg-white p-6 rounded-lg shadow-md transition-all duration-700 opacity-0 translate-y-10"
      ref={cardRef}
    >
      <div className="text-black mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-700">{description}</p>
    </div>
  );
};

const Benefits: React.FC = () => {
  const benefits = [
    {
      title: "Autenticidade em Cada Projeto",
      description: "Não seguimos tendências vazias. Criamos trabalhos que refletem a essência única de cada cliente, com propósito e verdade.",
      icon: <Heart size={32} />,
      delay: 0
    },
    {
      title: "Criatividade Multidisciplinar",
      description: "Música, arte, design, vídeo, foto — nossa versatilidade nos permite criar experiências completas e integradas para sua marca.",
      icon: <Sparkles size={32} />,
      delay: 100
    },
    {
      title: "Parceria Real",
      description: "Você não é apenas um cliente, é um colaborador. Trabalhamos lado a lado para entender sua visão e superar suas expectativas.",
      icon: <Users size={32} />,
      delay: 200
    },
    {
      title: "Compromisso com Excelência",
      description: "Cada detalhe importa. Do conceito inicial à entrega final, buscamos a perfeição em tudo o que fazemos.",
      icon: <Star size={32} />,
      delay: 300
    }
  ];

  return (
    <section id="benefits" className="py-24 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">Por que Escolher a Geneseez?</h2>
        <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">
          Mais do que uma empresa criativa, somos parceiros na construção de algo significativo.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <BenefitCard 
              key={index}
              title={benefit.title}
              description={benefit.description}
              icon={benefit.icon}
              delay={benefit.delay}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;
