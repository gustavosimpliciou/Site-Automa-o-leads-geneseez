import { useEffect, useRef } from 'react';
import { Music, Disc3, Play } from 'lucide-react';

const Projects: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const albumRef = useRef<HTMLDivElement>(null);

  const albumTracks = [
    "Faixa 01",
    "Faixa 02", 
    "Faixa 03",
    "Faixa 04",
    "Faixa 05",
    "Faixa 06",
    "Faixa 07",
    "Faixa 08",
    "Faixa 09"
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            entry.target.classList.remove('opacity-0', 'translate-y-10');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (albumRef.current) observer.observe(albumRef.current);

    return () => {
      if (albumRef.current) observer.unobserve(albumRef.current);
    };
  }, []);

  return (
    <section id="projects" className="py-24 bg-white">
      <div className="container mx-auto px-4" ref={containerRef}>
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">Nossos Projetos</h2>
        <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">
          Cada projeto é uma jornada. Aqui está nosso primeiro lançamento musical — o início de muitas criações.
        </p>
        
        <div 
          ref={albumRef}
          className="max-w-4xl mx-auto transition-all duration-1000 opacity-0 translate-y-10"
        >
          <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-black rounded-2xl overflow-hidden shadow-2xl">
            <div className="md:flex">
              <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
                <div className="flex items-center gap-2 mb-4">
                  <Disc3 className="text-white animate-spin" style={{ animationDuration: '3s' }} size={24} />
                  <span className="text-gray-400 text-sm uppercase tracking-widest">Lançamento</span>
                </div>
                
                <h3 className="text-4xl md:text-5xl font-bold text-white mb-2">
                  ÊXTASE 999
                </h3>
                
                <p className="text-gray-400 text-lg mb-6">
                  Artistas: <span className="text-white font-semibold">DIIVINU & LOPZ</span>
                </p>
                
                <p className="text-gray-300 mb-8 leading-relaxed">
                  Nosso primeiro projeto musical é uma viagem sonora que explora as fronteiras da criação. 
                  9 faixas que capturam a essência do êxtase criativo — onde a arte encontra a emoção pura. 
                  Este álbum representa tudo o que a Geneseez acredita: autenticidade, paixão e a coragem de criar algo novo.
                </p>

                <div className="flex items-center gap-4 mb-8">
                  <div className="flex items-center gap-2 text-gray-400">
                    <Music size={18} />
                    <span>9 Faixas</span>
                  </div>
                  <div className="w-1 h-1 bg-gray-600 rounded-full"></div>
                  <span className="text-gray-400">2024</span>
                </div>

                <button className="flex items-center justify-center gap-3 bg-white text-black font-semibold py-4 px-8 rounded-full hover:bg-gray-200 transition-all duration-300 transform hover:scale-105 w-full md:w-auto">
                  <Play size={20} fill="black" />
                  Em Breve
                </button>
              </div>

              <div className="md:w-1/2 bg-gradient-to-br from-purple-900/50 via-black to-gray-900 p-8 md:p-12">
                <h4 className="text-white font-semibold mb-6 flex items-center gap-2">
                  <Music size={18} />
                  Tracklist
                </h4>
                <ul className="space-y-3">
                  {albumTracks.map((track, index) => (
                    <li 
                      key={index}
                      className="flex items-center gap-4 text-gray-300 hover:text-white transition-colors group cursor-pointer"
                    >
                      <span className="text-gray-500 text-sm w-6 group-hover:hidden">
                        {String(index + 1).padStart(2, '0')}
                      </span>
                      <Play size={14} className="hidden group-hover:block text-white" />
                      <span className="flex-1">{track}</span>
                      <span className="text-gray-600 text-sm">--:--</span>
                    </li>
                  ))}
                </ul>
                
                <div className="mt-8 pt-6 border-t border-gray-700">
                  <p className="text-gray-500 text-sm italic">
                    "O êxtase não é um destino, é o caminho da criação."
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-600 mb-4">
              Este é apenas o começo. Mais projetos em música, arte visual, design e produção audiovisual estão por vir.
            </p>
            <p className="text-gray-500 text-sm">
              Quer fazer parte do próximo projeto? Entre em contato conosco.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;
