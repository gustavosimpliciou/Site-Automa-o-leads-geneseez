import { Instagram, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (section) {
      window.scrollTo({
        top: section.offsetTop - 100,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer className="bg-black text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div>
            <a 
              href="#home" 
              className="inline-block mb-6"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('home');
              }}
            >
              <img 
                src="/logo2.png" 
                alt="Geneseez" 
                className="h-8"
              />
            </a>
            <p className="text-gray-400 mt-4">
              Onde toda criação começa. Música, arte, design, vídeos e fotos — 
              transformamos ideias em experiências que marcam.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="#" className="text-gray-400 hover:text-white transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-6">Navegação</h3>
            <ul className="space-y-3">
              {[
                ['home', 'Início'],
                ['about', 'Sobre'],
                ['projects', 'Projetos'],
                ['contact', 'Contato']
              ].map(([id, label]) => (
                <li key={id}>
                  <a
                    href={`#${id}`}
                    className="text-gray-400 hover:text-white transition-colors"
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection(id);
                    }}
                  >
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-6">Contato</h3>
            <ul className="space-y-4">
              <li className="flex items-center">
                <Mail size={20} className="text-gray-400 mr-2" />
                <a href="mailto:contato@geneseez.com" className="text-gray-400 hover:text-white">
                  contato@geneseez.com
                </a>
              </li>
            </ul>
            <div className="mt-8">
              <h4 className="text-white font-medium mb-3">O que criamos</h4>
              <div className="flex flex-wrap gap-2">
                {['Música', 'Arte', 'Design', 'Vídeos', 'Fotos'].map((item) => (
                  <span key={item} className="text-gray-500 text-sm bg-gray-800 px-3 py-1 rounded-full">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-800 text-center md:flex md:justify-between md:text-left">
          <p className="text-gray-400">
            {new Date().getFullYear()} Geneseez. Todos os direitos reservados.
          </p>
          <p className="text-gray-500 mt-4 md:mt-0 text-sm">
            Onde toda criação começa.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
