[x] 1. Install the required packages
[x] 2. Restart the workflow to see if the project is working
[x] 3. Verify the project is working using the feedback tool
[x] 4. Inform user the import is completed and they can start building, mark the import as completed using the complete_project_import tool

## Rebranding Geneseez - Completed
[x] 1. Atualizar o componente Hero com nova mensagem sobre criação
[x] 2. Atualizar o componente About com a história da Geneseez
[x] 3. Atualizar o componente Benefits para mostrar serviços criativos
[x] 4. Reformular Projects para destacar o álbum ÊXTASE 999
[x] 5. Atualizar Header, Footer e outros componentes
[x] 6. Testar e verificar o resultado final
